## README / Notes

* **Shortcode**: use `[vestiaire_fee_calculator]` in any post/page/widget (text/html) to show the calculator.
* **Behavior**:

  * Email confirm required before inputs enable (same UX as previous plugins). Confirmed email persists to `localStorage` so it remains confirmed on refresh.
  * **Selling Fee** and **Payment Processing Fee** are country-specific and applied to the item sale price only.

    * United States, United Kingdom, Europe: selling fee = 10%, processing = 3%.
    * Canada: selling fee = 15%, processing = 4%.
  * **Total Fees** = selling fee + processing fee (rounded components).
  * **Earnings** = Item Price − Total Fees.
  * **Profit** = Earnings − Item Cost.
  * **Profit Margin** = Profit / Earnings × 100.
* **Design & theme integration**: CSS intentionally uses `font-family: inherit; color: inherit;` and CSS variables so button color/typography follow the theme/Elementor.
* You can change default rates via `add_filter('vestiaire_calc_rates', function($rates){ ... return $rates; });`