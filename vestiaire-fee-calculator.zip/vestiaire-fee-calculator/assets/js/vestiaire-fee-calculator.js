(function(){
    function qs(sel, el) { return (el || document).querySelector(sel); }
    var data = (window.VestiaireCalcData && window.VestiaireCalcData.rates) ? window.VestiaireCalcData.rates : {};

    document.addEventListener('DOMContentLoaded', function(){
        var root = qs('.vestiaire-calc');
        if(!root) return;

        var email = qs('#vestiaire-email', root);
        var confirmBtn = qs('#vestiaire-confirm-email', root);
        var clearBtn = qs('#vestiaire-clear', root);

        var inputs = [
            qs('#vestiaire-country', root),
            qs('#vestiaire-item-price', root),
            qs('#vestiaire-item-cost', root)
        ];

        var results = qs('#vestiaire-results', root);
        var resSelling = qs('#res-selling', root);
        var resProcessing = qs('#res-processing', root);
        var resTotal = qs('#res-total', root);
        var resEarnings = qs('#res-earnings', root);
        var resProfit = qs('#res-profit', root);
        var resMargin = qs('#res-margin', root);

        function setDisabledState(disabled){
            inputs.forEach(function(i){ if(i){ i.disabled = disabled; } });
            if(disabled){ root.classList.add('vestiaire-disabled'); results.style.display = 'none'; }
            else { root.classList.remove('vestiaire-disabled'); results.style.display = 'block'; }
        }

        // restore email state
        var savedEmail = localStorage.getItem('vestiaire_email') || '';
        var confirmed = localStorage.getItem('vestiaire_email_confirmed') === '1';
        if(savedEmail){ email.value = savedEmail; }
        if(confirmed && savedEmail){ confirmBtn.textContent = '✔ Email Confirmed'; confirmBtn.disabled = true; setDisabledState(false); }
        else { setDisabledState(true); }

        confirmBtn.addEventListener('click', function(){
            var val = email.value.trim();
            if(!val || !/\S+@\S+\.\S+/.test(val)){
                alert('Please enter a valid email to continue');
                return;
            }
            confirmBtn.textContent = '✔ Email Confirmed';
            confirmBtn.disabled = true;
            localStorage.setItem('vestiaire_email', val);
            localStorage.setItem('vestiaire_email_confirmed', '1');
            setDisabledState(false);
            calculate();
        });

        clearBtn.addEventListener('click', function(){
            email.value = '';
            confirmBtn.textContent = 'Confirm Email';
            confirmBtn.disabled = false;
            localStorage.removeItem('vestiaire_email');
            localStorage.removeItem('vestiaire_email_confirmed');
            inputs.forEach(function(i){ if(i){ if(i.type === 'checkbox') i.checked = false; else i.value = ''; } });
            setDisabledState(true);
            [resSelling,resProcessing,resTotal,resEarnings,resProfit,resMargin].forEach(function(el){ el.textContent='-'; el.classList.remove('positive','negative'); });
        });

        inputs.forEach(function(i){ if(!i) return; i.addEventListener('input', calculate); i.addEventListener('change', calculate); });

        function formatCurrency(val, symbol){
            if(isNaN(val)) return '-';
            var fixed = Number(val).toFixed(2);
            return symbol + fixed;
        }

        function calculate(){
            var country = (qs('#vestiaire-country', root).value || 'United States');
            var sale = parseFloat(qs('#vestiaire-item-price', root).value) || 0;
            var itemCost = parseFloat(qs('#vestiaire-item-cost', root).value) || 0;

            var rateObj = data[country] || data['United States'];
            var currency = (rateObj && rateObj.currency) ? rateObj.currency : '$';
            var sellingRate = (rateObj && rateObj.selling_fee) ? parseFloat(rateObj.selling_fee) : 0.10;
            var processingRate = (rateObj && rateObj.processing_fee) ? parseFloat(rateObj.processing_fee) : 0.03;

            var sellingFee = Number((sale * sellingRate).toFixed(2));
            var processingFee = Number((sale * processingRate).toFixed(2));
            var totalFees = Number((sellingFee + processingFee).toFixed(2));

            var earnings = Number((sale - totalFees).toFixed(2));
            var profit = Number((earnings - itemCost).toFixed(2));
            var margin = 0;
            if(earnings !== 0){ margin = Number(((profit / earnings) * 100).toFixed(1)); }

            resSelling.textContent = formatCurrency(sellingFee, currency);
            resProcessing.textContent = formatCurrency(processingFee, currency);
            resTotal.textContent = formatCurrency(totalFees, currency);
            resEarnings.textContent = formatCurrency(earnings, currency);
            resProfit.textContent = formatCurrency(profit, currency);
            resMargin.textContent = margin + '%';

            [resEarnings,resProfit].forEach(function(el){ el.classList.remove('positive','negative'); var num = parseFloat(el.textContent.replace(/[^0-9.-]+/g,'')); if(!isNaN(num) && num >= 0) el.classList.add('positive'); else el.classList.add('negative'); });
        }

    });
})();