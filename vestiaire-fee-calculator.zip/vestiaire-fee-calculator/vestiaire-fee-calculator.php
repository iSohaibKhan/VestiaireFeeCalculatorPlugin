<?php
/*
Plugin Name: Vestiaire Fee Calculator Shortcode
Plugin URI: https://sellercave.com/vestiaire-fee-calculator/
Description: Shortcode [vestiaire_fee_calculator] — responsive Vestiaire Collective fee calculator. Inherits theme colors & typography via CSS variables.
Version: 1.0.0
Author: Sohaib S. Khan
Author URI: https://isohaibkhan.github.io/
Text Domain: vestiaire-fee-calculator
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

function vestiaire_register_assets() {
    wp_register_style('vestiaire-fee-calculator-css', plugins_url('assets/css/vestiaire-fee-calculator.css', __FILE__));
    wp_register_script('vestiaire-fee-calculator-js', plugins_url('assets/js/vestiaire-fee-calculator.js', __FILE__), array('jquery'), '1.0', true);

    // Country-specific rates -> selling fee & payment processing rate
    $rates = array(
        'United States' => array('currency' => '$',  'selling_fee' => 0.10, 'processing_fee' => 0.03),
        'Canada'       => array('currency' => 'C$', 'selling_fee' => 0.15, 'processing_fee' => 0.04),
        'United Kingdom'=> array('currency' => '£', 'selling_fee' => 0.10, 'processing_fee' => 0.03),
        'Europe'       => array('currency' => '€',  'selling_fee' => 0.10, 'processing_fee' => 0.03),
    );

    $rates = apply_filters('vestiaire_calc_rates', $rates);

    wp_localize_script('vestiaire-fee-calculator-js', 'VestiaireCalcData', array(
        'rates' => $rates,
        'strings' => array(
            'info' => "Selling fee and payment processing vary by country. This tool calculates Selling Fee + Processing Fee, earnings & profit.",
        )
    ));
}
add_action('wp_enqueue_scripts', 'vestiaire_register_assets');

function vestiaire_fee_calculator_shortcode($atts = array()){
    // Enqueue when shortcode is used
    wp_enqueue_style('vestiaire-fee-calculator-css');
    wp_enqueue_script('vestiaire-fee-calculator-js');

    ob_start();
    ?>
    <div class="vestiaire-calc" aria-live="polite">
        <div class="card">
            <div class="top-row">
                <label class="label">Your Email <span class="required">*</span></label>
                <div class="email-row">
                    <div class="email-input-wrap">
                        <span class="email-icon">✉️</span>
                        <input id="vestiaire-email" type="email" placeholder="Enter your email" aria-label="Your email" />
                    </div>
                    <button id="vestiaire-confirm-email" class="btn" type="button">Confirm Email</button>
                    <button id="vestiaire-clear" class="btn btn-outline" type="button">Clear All</button>
                </div>
                <p class="help-text">Required for your fee calculation</p>
            </div>

            <div class="grid">
                <div class="form-group country">
                    <label>Country</label>
                    <select id="vestiaire-country">
                        <option>United States</option>
                        <option>Canada</option>
                        <option>United Kingdom</option>
                        <option>Europe</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Item Price</label>
                    <input id="vestiaire-item-price" type="number" min="0" step="0.01" />
                </div>

                <div class="form-group">
                    <label>Item Cost</label>
                    <input id="vestiaire-item-cost" type="number" min="0" step="0.01" />
                </div>
            </div>

            <div class="results" id="vestiaire-results" aria-hidden="true">
                <div class="result-row"><div class="label">Selling Fee:</div><div class="value" id="res-selling">-</div></div>
                <div class="result-row"><div class="label">Payment Processing Fee:</div><div class="value" id="res-processing">-</div></div>
                <div class="result-row total"><div class="label">Total Fees:</div><div class="value" id="res-total">-</div></div>
                <div class="result-row"><div class="label">Your Earnings:</div><div class="value" id="res-earnings">-</div></div>
                <div class="result-row"><div class="label">Your Profit:</div><div class="value" id="res-profit">-</div></div>
                <div class="result-row"><div class="label">Profit Margin:</div><div class="value" id="res-margin">-</div></div>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('vestiaire_fee_calculator', 'vestiaire_fee_calculator_shortcode');
